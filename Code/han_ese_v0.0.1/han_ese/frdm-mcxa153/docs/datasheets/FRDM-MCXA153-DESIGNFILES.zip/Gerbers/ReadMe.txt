README for GRB-90829_A.zip

Company Part Number: 170-90829 REV A

Date: Wed, 14 Jun 2023 06:49:41 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


All EQs are to be sent to the ENTIRE team listed below.

CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

CAD Manager
===========
Company Contact     : Ionut Manolescu
Work Phone          : ---
Email               : ionut.manolescu@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Product Engineer
================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Design Engineer
================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HWCOEPCBSolutions@msteams.nxp.com
