# Introduction

Welcome to these FRDM-MCXA153 example projects.

**Disclaimer**

This content is very preliminary and by no means finished!
Providing the content here is done for testing purposes.

## Prior knowledge and skills

- Representing numbers in different numbering systems, such as decimal, binary, and hexadecimal.
- C programming at the beginners level.
- Know the bitwise operators and what they are used for.
- Know what a register is.

## Contact

This content is part of the microcontroller courses by HAN Embedded Systems Engineering.

Have an comments or suggestions? Please get in contact by sending me an [email](mailto:hugo.arends@gmail.com).

*Hugo Arends*
<br>
Arnhem February 2024
