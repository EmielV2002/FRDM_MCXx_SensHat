# Standard Counter or Timer - match interrupt

<mark>TBD</mark>

## Goal



## Required hardware

- FRDM-MCXA153A board
- Logic analyzer (optional)

## CTIMER in match interrupt mode


## CTIMER configuration


## Test and verification

- Open the project ctimer_match_interrupt.
- Build and run the application.
- Verify that ...

## Final assignment

