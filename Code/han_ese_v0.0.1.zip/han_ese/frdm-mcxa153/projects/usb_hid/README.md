# USB HID

<mark>TBD</mark>

## Goal



## Required hardware

- FRDM-MCXA153A board

## USB human interface device class


## Test and verification

- Open the project usb_hid.
- Build and run the application.
- Verify that ...

## Final assignment

