# Standard Counter or Timer - PWM

<mark>TBD</mark>

## Goal



## Required hardware

- FRDM-MCXA153A board
- Logic analyzer

## CTIMER in PWM mode


## CTIMER configuration


## Test and verification

- Open the project ctimer_pwm.
- Build and run the application.
- Verify that ...

## Final assignment

